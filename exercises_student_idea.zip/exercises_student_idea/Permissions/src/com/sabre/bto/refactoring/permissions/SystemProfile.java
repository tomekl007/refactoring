package com.sabre.bto.refactoring.permissions;

public class SystemProfile {

}
