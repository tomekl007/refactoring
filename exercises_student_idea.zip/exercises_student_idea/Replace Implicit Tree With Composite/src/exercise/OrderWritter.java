package exercise;

import exercise.exceptions.UnsupportedColorException;
import exercise.exceptions.UnsupportedSizeException;

import java.awt.*;

public class OrderWritter {

    private Orders orders;

    public OrderWritter(Orders orders) {
        this.orders = orders;
    }

    /*
   * Replace implicit tree with Composite
   * */
    public String writeOrders() throws UnsupportedSizeException, UnsupportedColorException {
        StringBuffer xml = new StringBuffer();
        xml.append("<orders>");
        for(int i = 0; i < orders.getOrderCount(); i++){
            Order order = orders.getOrder(i);
            xml.append("<order id='");
            xml.append(order.getOrderId());
            xml.append("'>");
            for(int j=0; j < order.getProductCount(); j++){
                Product product = order.getProduct(j);
                xml.append("<product id='");
                xml.append(product.getID());
                xml.append("'");
                xml.append(" color='");
                xml.append(getColorFor(product));
                xml.append("'");
                if(product.getSize() != ProductSize.NOT_APPLICABLE){
                    xml.append(" size='");
                    xml.append(getSizeFor(product));
                    xml.append("'");
                }
                xml.append(">");
                xml.append("<price currency='");
                xml.append(getCurrencyFor(product));
                xml.append("'>");

                xml.append(product.getPrice());
                xml.append("</price>");
                xml.append(product.getName());
                xml.append("</product>");
            }
            xml.append("</order>");
        }
        xml.append("</orders>");

        return xml.toString();
    }

    private String getCurrencyFor(Product product) {
        return "USD";
    }

    private String getSizeFor(Product product) throws UnsupportedSizeException {
        ProductSize productSize = product.getSize();
        switch (productSize){
            case SMALL:
                return "small";
            case MEDIUM:
                return "medium";
            case LARGE:
                return "large";
        }
        throw new UnsupportedSizeException();
    }

    private String getColorFor(Product product) throws UnsupportedColorException {
        Color color = product.getColor();
        if( color.equals(Color.red))
            return "red";
        if( color.equals(Color.green))
            return "green";
        if( color.equals(Color.blue))
            return "blue";

        throw new UnsupportedColorException();
    }

}
