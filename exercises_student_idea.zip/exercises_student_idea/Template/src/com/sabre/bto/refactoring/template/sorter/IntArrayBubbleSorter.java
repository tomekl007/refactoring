package com.sabre.bto.refactoring.template.sorter;


public class IntArrayBubbleSorter implements Sorter<int[]>{

    public int sort(int[] array) {
        int operations = 0;
        if (array.length <= 1)
            return operations;

        for (int nextToLast = array.length - 2; nextToLast >= 0; nextToLast--)
            for (int index = 0; index <= nextToLast; index++) {
               if (array[index] > array[(index + 1)]) {
                   int temp = array[index];
                   array[index] = array[(index + 1)];
                   array[(index + 1)] = temp;
                }
                operations++;
            }

        return operations;
    }

}