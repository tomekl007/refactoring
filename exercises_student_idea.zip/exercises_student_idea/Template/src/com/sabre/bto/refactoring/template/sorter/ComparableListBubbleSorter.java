package com.sabre.bto.refactoring.template.sorter;
import java.util.List;

public class ComparableListBubbleSorter<T extends Comparable<T>> implements Sorter<List<T>> {

   public int sort(List<T> subject) {
      int operations = 0;
      if (subject.size() <= 1)
         return operations;

      for (int nextToLast = subject.size() - 2; nextToLast >= 0; nextToLast--)
         for (int index = 0; index <= nextToLast; index++) {
            if (subject.get(index).compareTo(subject.get(index + 1)) > 0) {
               T temp = subject.get(index);
               subject.set(index, subject.get(index + 1));
               subject.set(index + 1,temp);
            }
            operations++;
         }

      return operations;
   }
}
