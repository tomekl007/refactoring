package car.parts;

public interface Pedal {
    void press();
    void release();
    boolean isPressed() ;

}
