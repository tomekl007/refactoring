package exercise.exceptions;

public class UnsupportedColorException extends Exception {
}
