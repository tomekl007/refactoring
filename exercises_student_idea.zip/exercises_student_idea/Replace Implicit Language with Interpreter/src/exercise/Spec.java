package exercise;

public interface Spec {
    boolean isSatisfyedBy(Product product);
}
