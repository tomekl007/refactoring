package com.sabre.bto.refactoring.command;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import java.math.BigDecimal;

/*
<?xml version="1.0" encoding="UTF-8"?>
<catalog>
    <book isbn=">23-34-42-3" lang="ENG">
        <title>Operating Systems</title>
        <price>400</price>
        <authors>
            <author>Ganesh Tiwari</author>
        </authors>
    </book>
    <book isbn="24-300-042-3">
        <title>Distributed Systems</title>
        <price>500</price>
        <authors>
            <author>Mahesh Poudel</author>
            <author>Bikram Adhikari</author>
            <author>Ramesh Poudel</author>
        </authors>
    </book>
</catalog>
*/

public class CatalogApp {
   public static final String ACTION_ADD_BOOK = "ADD_BOOK";
   public static final String ACTION_DELETE_BOOK = "DELETE_BOOK";
   public static final String ACTION_GET_BOOK_BY_ISBN = "GET_BOOK_BY_ISBN";
   public static final String ACTION_GET_ALL_BOOKS = "GET_ALL_BOOKS";

   public static final String BOOK_TITLE = "BOOK_TITLE";
   public static final String BOOK_ISBN  = "BOOK_ISBN";
   public static final String BOOK_PRICE = "BOOK_PRICE";
   public static final String BOOK_AUTHORS = "BOOK_AUTHORS";

   private XmlBooksCreator xmlCreator = new XmlBooksCreator();
   private BookManager workshopManager;
   
   CatalogApp(BookManager manager) {
      workshopManager = manager;
   }

   public HandlerResponse executeActionAndGetResponse(String actionName, Map<String, String> parameters) {
      if (actionName.equals(ACTION_ADD_BOOK)) {         
         Book book = getBookFromParameters(parameters);         
         workshopManager.addBook(book);
         return new HandlerResponse(xmlCreator.getAsXml(workshopManager.getAllBooks()), ResponseType.ADDED);
      } 
      else if (actionName.equals(ACTION_DELETE_BOOK)) {         
         workshopManager.removeBook(parameters.get(BOOK_ISBN));
         return new HandlerResponse(xmlCreator.getAsXml(workshopManager.getAllBooks()), ResponseType.DELETED);
      } 
      else if (actionName.equals(ACTION_GET_BOOK_BY_ISBN)) {
         Book book = workshopManager.getBook(parameters.get(BOOK_ISBN));
         if (book == null)
         {
            return new HandlerResponse(xmlCreator.getAsXml(Collections.<Book>emptyList()), ResponseType.NOT_FOUND);
         }
         else
         {
            return new HandlerResponse(xmlCreator.getAsXml(Arrays.asList(book)), ResponseType.OK);
         }
      } 
      else if (actionName.equals(ACTION_GET_ALL_BOOKS)) {
         return new HandlerResponse(xmlCreator.getAsXml(workshopManager.getAllBooks()), ResponseType.OK);
      } 
      
      throw new UnsupportedOperationException();
   }

   private Book getBookFromParameters(Map<String, String> parameters) {
      Book book = new Book();
      
      book.setIsbn(parameters.get(BOOK_ISBN));
      book.setTitle(parameters.get(BOOK_TITLE));
      book.setPrice(new BigDecimal(parameters.get(BOOK_PRICE)));
      
      String[] authors = parameters.get(BOOK_AUTHORS).split(",");      
      book.setAuthors(Arrays.asList(authors));
      
      return book;
   }
}