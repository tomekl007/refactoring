package com.sabre.bto.refactoring.command;

public enum ResponseType {
   OK, NOT_FOUND, ADDED, MODIFIED, DELETED
}
