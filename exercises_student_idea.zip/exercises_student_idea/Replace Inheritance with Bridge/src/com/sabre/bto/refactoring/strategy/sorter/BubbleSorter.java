package com.sabre.bto.refactoring.strategy.sorter;


public abstract class BubbleSorter<S> implements Sorter<S> {
   protected S subject;

   @Override
   public int sort(S subject) {
      this.subject = subject;
      int length = getLength();
      int operations = 0;
      if (length <= 1)
         return operations;

      for (int nextToLast = length - 2; nextToLast >= 0; nextToLast--)
         for (int index = 0; index <= nextToLast; index++) {
            if (compare(index, index + 1) > 0)
               swap(index, index + 1);
            operations++;
         }

      return operations;
   }

   protected abstract int getLength();

   protected abstract int compare(int i, int j);

   protected abstract void swap(int i, int j);
}
