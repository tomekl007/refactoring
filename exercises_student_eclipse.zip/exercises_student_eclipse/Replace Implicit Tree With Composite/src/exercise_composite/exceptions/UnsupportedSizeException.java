package exercise_composite.exceptions;

public class UnsupportedSizeException extends Throwable {
}
