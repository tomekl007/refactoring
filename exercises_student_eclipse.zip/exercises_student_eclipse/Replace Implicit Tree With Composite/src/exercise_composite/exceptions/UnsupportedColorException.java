package exercise_composite.exceptions;

public class UnsupportedColorException extends Exception {
}
