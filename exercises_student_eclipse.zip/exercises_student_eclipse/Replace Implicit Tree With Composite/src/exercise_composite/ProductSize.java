package exercise_composite;

public enum ProductSize {
    NOT_APPLICABLE,
    SMALL,
    MEDIUM,
    LARGE
}
