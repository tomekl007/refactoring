package com.sabre.bto.refactoring.strategy.sorter;

import org.junit.Test;


public class StrategySorterTest {
   @Test
   public void testSort() throws Exception {

   }
}
