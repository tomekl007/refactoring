package car.parts;

public interface AutomaticGearbox {

    void setDrive();
    void setPark();
    boolean isDrive();
}
