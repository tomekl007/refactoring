package car.parts;

public interface Engine{
    void turnOn();
    void turnOff();
    boolean isOn();
}
