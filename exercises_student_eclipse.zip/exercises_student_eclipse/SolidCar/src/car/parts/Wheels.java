package car.parts;

public interface Wheels {
    void startSpinning();
    void stopSpinning();
    boolean areSpinning();
}
