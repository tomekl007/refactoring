package exercise;

public enum ProductSize {
    NOT_APPLICABLE,
    SMALL,
    MEDIUM,
    LARGE
}
