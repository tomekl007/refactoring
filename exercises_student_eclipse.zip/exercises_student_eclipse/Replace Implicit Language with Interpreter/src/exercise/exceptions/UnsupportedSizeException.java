package exercise.exceptions;

public class UnsupportedSizeException extends Throwable {
}
