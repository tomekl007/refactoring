package com.sabre.bto.refactoring.new_permissions;

public class SystemUser {

}
